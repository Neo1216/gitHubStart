
/**
 * Write a description of interface FuelTank here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface FuelTank
{
    /**  @return  an integer value that ranges from 0 (empty) to 100 (full)*/
    
    int getFuelLevel();
}
