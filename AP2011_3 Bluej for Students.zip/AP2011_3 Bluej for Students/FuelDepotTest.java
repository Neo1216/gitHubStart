
import java.util.List;
import java.util.ArrayList;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class FuelDepotTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class FuelDepotTest
{
    private FuelDepot fuelDepo1,fuelDepo2;
    private List<FuelTank> tanks1,tanks2;
    /**
     * Default constructor for test class FuelDepotTest
     */
    public FuelDepotTest()
    {
        int [] levels1 = {80,70,20,45,50,25};
        tanks1 = new ArrayList<FuelTank>();
        for(int n: levels1)
        {
            tanks1.add(new LargeTank(n));
        }
        fuelDepo1 = new FuelDepot(tanks1);
       
        int [] levels2 = {20,30,80,55,50,75,21};
        tanks2 = new ArrayList<FuelTank>();
        for(int n: levels2)
        {
            tanks2.add(new LargeTank(n));
        }
        fuelDepo2 = new FuelDepot(tanks2);
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
       
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void nextTanktoFill1()
    {
        assertEquals(2, fuelDepo1.nextTankToFill(60));
    }
    
    @Test
    public void nextTanktoFill2()
    {
        assertEquals(0, fuelDepo2.nextTankToFill(30));
    }
    
    @Test
    public void moveToLocation1()
    {
        fuelDepo1.moveToLocation(5);
        assertEquals(5, fuelDepo1.getRobotLocation());
    }
    
    @Test
    public void moveToLocation2()
    {
        fuelDepo1.moveToLocation(0);
        assertEquals(0, fuelDepo1.getRobotLocation());
    }
}

