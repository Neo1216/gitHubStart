
public class LargeTank implements FuelTank
{
    private int level;
    public LargeTank(int l){
        level = l;
    }
    
    public int getFuelLevel(){
        return level;
    }
    
}
