import java.util.ArrayList;
import java.util.List;
public class FuelDepot
{
    /** The robot used to move the filling mechanism */
    private FuelRobot filler;
    /** A list of fuel tanks */
    private List<FuelTank> tanks;

    /**
     * Constructor for objects of class FuelDepot
     */
    public FuelDepot(List<FuelTank> t)
    {
        filler = new FuelRobot2000();
        tanks = t;
    }
    
    /** 
     * added for testing 
     */
    public int getRobotLocation(){
        return filler.getCurrentIndex();
    }
    
    /**
     * Determines and returns the index of the next tank to be filled.
     * @param threshold fuel tanks with a fuel level ≤ threshold may be filled
     * @param index of the location of the next tank to be filled
     * Postcondition:  the state of the robot has not changed
     */
    public int nextTankToFill(int threshold)
    { /*to be implemented in part (a) */
       
    }

    /**
     * Moves the robot to location locIndex.
     * @param locIndex the index of the location of the tank to move to
     *          Precondition:  0 ≤ locIndex ≤tank.size()
     * Postcondition: the current location of the robot is locIndex
     */
    public void moveToLocation (int locIndex)
    { /*to be implemented in part (b) */

    }
}
